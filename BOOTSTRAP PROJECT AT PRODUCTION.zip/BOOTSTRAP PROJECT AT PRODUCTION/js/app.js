
$(".modal")delay(5000).modal("show"); // hide toggle
//$(".modal").hide(5000);